

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
      .then(function() {
        console.log('SW registered');
      });
  }
  

// function check(form)/*function to check userid & password*/
// {

// {
        
//     var welcome;
    
//         var date = new Date();
    
//         var hour = date.getHours();
    
//         var minute = date.getMinutes();
    
//         var second = date.getSeconds();
    
//         if (minute < 10) {
    
//             minute = "0" + minute;
    
//         }
    
//         if (second < 10) {
    
//             second = "0" + second;
    
//         }
    
//         if (hour < 12) {
    
//             welcome = "Good morning";
    
//         }
    
//         else if (hour < 17) {
    
//             welcome = "Good afternoon";
    
//         }
    
//         else {
    
//             welcome = "Good evening";
    
//         }
// }


// if(form.uname.value == "praveen" && form.psw.value == "12345")
// {
//    alert("In function");
//   window.localStorage.setItem('Username', 'Praveen');
//   alert("Login successfull");

//   window.open("/login.html","_self");
//   return true;
// }
// else
// {
//  alert("Error Password or Username")/*displays error message*/
// }




//  /*the following code checkes whether the entered userid and password are matching*/
//  if(form.uname.value == "praveen" && form.psw.value == "123456")
//   {
//      // alert("In function");
//     window.localStorage.setItem('Username', 'Praveen');
//     alert("Login successfull");
//     var username=localStorage.getItem('Username')
//     document.getElementById('username').innerHTML="Hello "+","+welcome;
//     document.getElementById('login-corner').innerHTML=username;
//     document.querySelector('#navbtn').style.display='none';
//     document.querySelector('#span-top').style.display='none';
//     document.querySelector('#id01').style.display='none'
//     document.querySelector('#log-features').style.display='block';
//     document.querySelector('#googleMap').style.display='none';
    
// }
//  else
//  {
//    alert("Error Password or Username")/*displays error message*/
//   }

// }
// function display()
// {
//     document.querySelector('#log-features').style.display='none';
//     document.querySelector('#googleMap').style.display='block';
// }
 
var data1;

   $('#requestShiping').click(function() {
    
jQuery.ajax({
    url     : 'http://104.42.77.186:8100/api/requestcustomer',
    async   : true,
    dataType: 'application/json',
    type    : 'POST',
    data    : {
        product_name: jQuery("#product_name").val(),
        product_weight: jQuery("#product_weight").val(),
        from: jQuery("#from").val(),
        to: jQuery("#to").val(),
        product_type:jQuery("#product_type").val(),
        address: jQuery("#address").val(),
        countryId: jQuery("#countryId").val(),
        stateId: jQuery("#stateId").val(),
        cityId:jQuery("#cityId").val(),
        zipcode: jQuery("#zipcode").val(),
        phonenumber: jQuery("#phonenumber").val(),
        email: jQuery("#email").val(),
        status: "pending",
        requestedby:"Praveen"
     
    }
}).done(function() {
    // Handle Success
    alert("request raise");
}).fail(function(xhr, status, error) {
   // Handle Failure
   alert("Request is Raised");
   window.location.replace("/login.html"); 
     

});
  });



 function requests()
 {
    $.getJSON( "http://104.42.77.186:8100/api/requestcustomer", function( data ) {
        var items = [];
        $.each( data, function( key, val ) {
          items.push(val);
        });
         data1=(items[2]);
        var trHTML = '';
    
       $.each(  data1, function( key, val ) {
       console.log(key);
       if(val.status=="pending"){
                trHTML += '<tr><td>' +(key+1)+ '</td><td>' + val.requestedby + '</td><td>' + val.product_name + '</td><td>' + val.from + '</td><td>' + val.to + '</td><td>' + '<a href=details.html?id='+val._id  + '>Details</a></td></tr>';
       }
        });
    
        $('#data').append(trHTML);
       });
    
 }


function completerequest() {
  $.getJSON( "http://104.42.77.186:8100/api/requestcustomer", function( data ) {
    var items = [];
    $.each( data, function( key, val ) {
      items.push(val);
    });
     data1=(items[2]);
var trHTML = '';
   $.each(  data1, function( key, val ) {
   console.log(key);
   if(val.status=="completed"){
            trHTML += '<tr><td>' +(key+1)+ '</td><td>' + val.requestedby + '</td><td>' + val.product_name + '</td><td>' + val.from + '</td><td>' + val.to + '</td><td>' + '<a href=details.html?id='+val._id  + '>Details</a></td></tr>';
        }
 });
    $('#completedata').append(trHTML);
   });
}


function Inprocessdata()
{
    $.getJSON( "http://104.42.77.186:8100/api/requestcustomer", function( data ) {
        var items = [];
        $.each( data, function( key, val ) {
          items.push(val);
        });
         data1=(items[2]);
    var trHTML = '';
       $.each(  data1, function( key, val ) {
       console.log(key);
       if(val.status=="Inprocess"){
                trHTML += '<tr><td>' +(key+1)+ '</td><td>' + val.requestedby + '</td><td>' + val.product_name + '</td><td>' + val.from + '</td><td>' + val.to + '</td><td>' + '<a href=details.html?id='+val._id  + '>Details</a></td></tr>';
            }
     });
        $('#inprocessdata').append(trHTML);
       });

}
  
    // $("#getdetails").click(function(){
       

    //     jQuery.ajax({
    //         url: "http://localhost:8080/api/requestcustomer",
    //         type: "GET",
    //         headers: {  
    //             'Access-Control-Allow-Credentials' : true,  
    //             'Access-Control-Allow-Origin': '*',  
    //             'Access-Control-Allow-Methods':'GET',  
    //             'Access-Control-Allow-Headers':'application/json',  
    //              },  
    //         contentType: 'application/json; charset=utf-8',
    //         success: function(resultData) {
    //             //here is your json.
    //               // process it
    //               console.log(resultData);
    //               $.each(resultData, function( key, value ) {
    //               //   alert( key + ": " + value );
                                         
                                       
    //               });

    //         },
    //         error : function(jqXHR, textStatus, errorThrown) {
    //         },

    //         timeout: 120000,
    //     });
   
       
    // });


    // function CreateTableFromJSON() {
    //     console.log(data1);
    //     var myBooks = data1;

    //     // EXTRACT VALUE FOR HTML HEADER. 
    //     // ('Book ID', 'Book Name', 'Category' and 'Price')
    //     var col = [];
    //     for (var i = 0; i < myBooks.length; i++) {
    //         for (var key in myBooks[i]) {
    //             if (col.indexOf(key) === -1) {
    //                 col.push(key);
    //             }
    //         }
    //     }

    //     // CREATE DYNAMIC TABLE.
    //     var table = document.createElement("table");

    //     // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.

    //     var tr = table.insertRow(-1);                   // TABLE ROW.

    //     for (var i = 0; i < col.length; i++) {
    //         var th = document.createElement("th");      // TABLE HEADER.
    //         th.innerHTML = col[i];
    //         tr.appendChild(th);
    //     }

    //     // ADD JSON DATA TO THE TABLE AS ROWS.
    //     for (var i = 0; i < myBooks.length; i++) {

    //         tr = table.insertRow(-1);

    //         for (var j = 0; j < col.length; j++) {
    //             var tabCell = tr.insertCell(-1);
    //             tabCell.innerHTML = myBooks[i][col[j]];
    //         }
    //     }

    //     // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
    //     var divContainer = document.getElementById("showData");
    //     divContainer.innerHTML = "";
    //     divContainer.appendChild(table);
    // }



    // ====================================================user registration=============================


    
   $( '#signup').click(function() {
    console.log( username, jQuery("#username").val(),
    countryId, jQuery("#countryId").val(),
    stateId,jQuery("#stateId").val(),
    cityId,jQuery("#cityId").val(),
    zipcode1,jQuery("#zipcode1").val(),
    phonenumber1, jQuery("#phonenumber1").val(),
    email,jQuery("#email").val(),
    password,jQuery("#password").val())
    
    jQuery.ajax({
        url     : 'http://104.42.77.186:8100/api/Signup',
        async   : true,
        dataType: 'application/json',
        type    : 'POST',
        data    : {
            username: jQuery("#username").val(),
            address: jQuery("#address1").val(),
            countryId: jQuery("#countryId").val(),
            stateId: jQuery("#stateId").val(),
            cityId:jQuery("#cityId").val(),
            zipcode: jQuery("#zipcode1").val(),
            phonenumber: jQuery("#phonenumber1").val(),
            email: jQuery("#email").val(),
            password:jQuery("#password").val()
          
           

         
        }
    }).done(function() {
        // Handle Success
        alert("User Not registered");
    }).fail(function(xhr, status, error) {
       // Handle Failure
       alert("User Registered");
       
    });
      });