var map, datasource, routePoints = [], currentScenario,controls,marker;
var routeCoordinates = [],datasource1,distance;
var startPoint,endPoint,subscriptionKeyCredential,pipeline,routeURL;
var coordinateRx = /^-?[0-9]+\.?[0-9]*\s*,+\s*-?[0-9]+\.?[0-9]*$/;
var geocodeRequestUrl = 'https://atlas.microsoft.com/search/address/json?subscription-key={subscription-key}&api-version=1&query={query}';
var carRoutingRequestUrl = 'https://atlas.microsoft.com/route/directions/json?subscription-key={subscription-key}&api-version=1&query={query}&routeRepresentation=polyline&travelMode=car';
var truckRoutingRequestUrl = 'https://atlas.microsoft.com/route/directions/json?subscription-key={subscription-key}&api-version=1&query={query}&routeRepresentation=polyline&vehicleLength={vehicleLength}&vehicleHeight={vehicleHeight}&vehicleWidth={vehicleWidth}&vehicleWeight={vehicleWeight}&travelMode=truck';
var scenarios = [
    { from: '47.632241,-122.299189', to: '47.634676,-122.300302', height: '5', width: '3', length: '', weight: '', load: [], description: 'Low bridge', streetsideLink: 'https://binged.it/2oT6d4V' },
    { from: '47.586514,-122.245874', to: '47.584868,-122.243094', height: '', width: '', length: '30', weight: '', load: [], description: 'Tight turn', streetsideLink: 'https://binged.it/2v2gal8' },
    { from: '40.429993,-79.998690', to: '40.414211,-80.009550', height: '', width: '', length: '', weight: '', load: ['USHazmatClass3'], description: 'Flammable load', streetsideLink: 'https://binged.it/2hd6P3s' }
];



function GetMap() {
    document.getElementById("Assingnbtn").disabled = true;
    document.getElementById("mybtn").disabled = false;
    stop()
    //Initialize a map instance.
    map = new atlas.Map('myMap', {
        //Add your Azure Maps subscription key to the map SDK. Get an Azure Maps key at https://azure.com/maps
        authOptions: {
            authType: 'subscriptionKey',
            subscriptionKey:'HgqenYrB7LRNgoAK4dy8noJ0gsw759iDDZ6PkX5zB-M'
        }
    });
    //Wait until the map resources are ready.
    map.events.add('ready', function () {

        addControls();
     
        //Create a data source to store the data in.
        datasource = new atlas.source.DataSource();
        map.sources.add(datasource);
        //Add a layer for rendering line data.
        map.layers.add(new atlas.layer.LineLayer(datasource, null, {
            strokeColor: ['get', 'strokeColor'],
            strokeWidth: 4
        }), 'labels');
        //Add a layer for rendering point data.
        map.layers.add(new atlas.layer.SymbolLayer(datasource, null, {
            iconOptions: {
                image: ['get', 'icon']
            },
            textOptions: {
                textField: ['get', 'title'],
                size: 14,
                font: ['SegoeUi-Bold'],
                offset: [0, 1.2]
            },
            filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']] //Only render Point or MultiPoints in this layer.
        }));
       
    });
   

}
function calculateDirections() {
    routePoints = [];
    document.getElementById("Assingnbtn").disabled = false;
    document.getElementById("mybtn").disabled = true;

    document.getElementById('output').innerHTML = '';
    datasource.clear();
    var from = document.getElementById('fromTbx').value;
    console.log(from);

    geocodeQuery(from, function (fromCoord) {
        var to = document.getElementById('toTbx').value;
    console.log(to);

        geocodeQuery(to, function (toCoord) {
            //Create pins for the start and end of the route.
            startPoint = new atlas.data.Point(fromCoord);
            console.log(startPoint.coordinates[0],startPoint.coordinates[1]);
          
                var startPin = new atlas.data.Feature(startPoint, {
                    title: 'Start',
                    icon: 'pin-round-blue'
                    
                });


            
            endPoint = new atlas.data.Point(toCoord);
            console.log(endPoint.coordinates[0],endPoint.coordinates[1]);

            var endPin = new atlas.data.Feature(endPoint, {
                title: 'End',
                icon: 'pin-round-red'
            });


            // marker1 = new atlas.HtmlMarker({
            //     htmlContent: "<div><div class='pin bounce'></div><div class='pulse'><h3>Start<h3></div></div>",
                
            //     pixelOffset: [5, -18],
            //     position: [startPoint.coordinates[0],startPoint.coordinates[1]]
            // });
            // marker2 = new atlas.HtmlMarker({
            //     htmlContent: "<div><div class='pin bounce'></div><div class='pulse'><h3>End<h3></div></div>",
              
            //     pixelOffset: [5, -18],
            //     position: [endPoint.coordinates[0],endPoint.coordinates[1]],
            //     title:'End'
            // });


            // map.markers.add(marker1);
            // map.markers.add(marker2);


            //Fit the map window to the bounding box defined by the start and end points.
            map.setCamera({
                bounds: atlas.data.BoundingBox.fromData([toCoord, fromCoord]),
                pitch: 45,
                padding: 50
            });
            //Add pins to the map for the start and end point of the route.
            datasource.add([startPin, endPin]);
            //Convert lon,lat into lat,lon.
            fromCoord.reverse();
            toCoord.reverse()
            var query = fromCoord.join(',') + ':' + toCoord.join(',');
            // var carRequestUrl = carRoutingRequestUrl.replace('{subscription-key}', atlas.getSubscriptionKey()).replace('{query}', query);
            // callRestService(carRequestUrl, function (r) {
            //     addRouteToMap(r.routes[0], 'red');
            //     document.getElementById('output').innerHTML += 'Car Distance: ' + Math.round(r.routes[0].summary.lengthInMeters / 10) / 100 + ' km<br/>';
            // });
            var truckRequestUrl = truckRoutingRequestUrl.replace('{subscription-key}', atlas.getSubscriptionKey()).replace('{query}', query);
            var loadType = getSelectValues('vehicleLoadType');
            if (loadType && loadType !== '') {
                truckRequestUrl += '&vehicleLoadType=' + loadType;
            }
            truckRequestUrl = setValueOptions(truckRequestUrl, ['vehicleWeight', 'vehicleWidth', 'vehicleHeight', 'vehicleLength']);
            callRestService(truckRequestUrl, function (r) {
                addRouteToMap(r.routes[0], 'green');
             

                document.getElementById('output').innerHTML += 'Truck Distance: ' + Math.round(r.routes[0].summary.lengthInMeters / 10) / 100 + ' km<br/>';
                distance= Math.round(r.routes[0].summary.lengthInMeters / 10) / 100;
            });
        });
    });
}
//Geocode the query and return the first coordinate.
function geocodeQuery(query, callback) {
    if (callback) {
        //Check to see if the query is a coordinate. if so, it doesn't need to be geocoded.
        if (coordinateRx.test(query)) {
            var vals = query.split(',');
            callback([parseFloat(vals[1]), parseFloat(vals[0])]);
        } else {
            var requestUrl = geocodeRequestUrl.replace('{subscription-key}', atlas.getSubscriptionKey()).replace('{query}', encodeURIComponent(query));
            callRestService(requestUrl, function (r) {
                if (r && r.results && r.results.length > 0) {
                    callback([r.results[0].position.lon, r.results[0].position.lat]);
                }
            });
        }
    }
}
function addRouteToMap(route, strokeColor) {
    
    for (var legIndex = 0; legIndex < route.legs.length; legIndex++) {
        var leg = route.legs[legIndex];
        //Convert the route point data into a format that the map control understands.
        var legCoordinates = leg.points.map(function (point) {
            return [point.longitude, point.latitude];
        });
        //Combine the route point data for each route leg together to form a single path.
        routeCoordinates = routeCoordinates.concat(legCoordinates);
    }
    //Create a LineString from the route path points and add it to the line layer.
    datasource.add(new atlas.data.Feature(new atlas.data.LineString(routeCoordinates), {
        strokeColor: strokeColor
    }));
    //Fit the map window to the bounding box defined by the route points.
    routePoints = routePoints.concat(routeCoordinates);
    map.setCamera({
        bounds: atlas.data.BoundingBox.fromPositions(routePoints),
        padding:30
    });
}
function callRestService(requestUrl, callback, errorCallback) {
    if (callback) {
        var xhttp = new XMLHttpRequest();
        xhttp.open('GET', requestUrl, true);
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (this.status == 200) {
                    var response = JSON.parse(xhttp.responseText);
                    callback(response);
                } else if (errorCallback) {
                    if (errorCallback) {
                        errorCallback(JSON.parse(xhttp.responseText));
                    }
                }
            }
        };
        xhttp.send();
    }
}
// Return a set of the selected opion value for a multi-select as a comma delimited string.
function getSelectValues(id) {
    var select = document.getElementById(id);
    var selected = [];
    for (var i = 0; i < select.length; i++) {
        if (select.options[i].selected) {
            selected.push(select.options[i].value);
        }
    }
    return selected.join(',');
}
function setValueOptions(requestUrl, valueOptions) {
    for (var i = 0; i < valueOptions.length; i++) {
        requestUrl = requestUrl.replace('{' + valueOptions[i] + '}', document.getElementById(valueOptions[i]).value);
    }
    return requestUrl;
}
function addControls() {
 //   map.controls.remove(controls);
    controls = [];

    //Get input options.
    //var positionOption = getSelectValue('controlPosition');
  // var controlStyle = getSelectValue('controlStyle');

    //Create a zoom control.
    controls.push(new atlas.control.ZoomControl({
        zoomDelta: parseFloat(1),
        style: "dark"
    }));

    //Create a pitch control and add it to the map.
    controls.push(new atlas.control.PitchControl({
        pitchDegreesDelta: parseFloat(45),
        style: "dark"
    }));

    //Create a compass control and add it to the map.
    controls.push(new atlas.control.CompassControl({
        rotationDegreesDelta: parseFloat(45),
        style: "dark"
    }));

    //Create a style control and add it to the map.
    controls.push(new atlas.control.StyleControl({
        style: "dark"            }));

    //Add controls to the map.
    map.controls.add(controls, {
        position: "top-right"
    });
}



// ===============================trafic===============================
function traffic(){

    document.getElementById("mybtn").disabled = true;

map.events.add('ready', function () {
    // Add Traffic Flow to the Map
    map.setTraffic({
        incidents: true,
        flow: "absolute"
    });
    //Create a data source and add it to the map.
   //datasource = new atlas.source.DataSource();
    map.sources.add(datasource);
    //Add a layer for rendering the route lines and have it render under the map labels.
    map.layers.add(new atlas.layer.LineLayer(datasource, null, {
        strokeColor: ['get', 'strokeColor'],
        strokeWidth: ['get', 'strokeWidth'],
        lineJoin: 'round',
        lineCap: 'round'
    }), 'labels');
    //Add a layer for rendering point data.
    map.layers.add(new atlas.layer.SymbolLayer(datasource, null, {
        iconOptions: {
            image: ['get', 'icon'],
            allowOverlap: true
        },
        textOptions: {
            textField: ['get', 'title'],
            offset: [0, 1.2]
        },
        filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']] //Only render Point or MultiPoints in this layer.
    }));
    //Create the GeoJSON objects which represent the start and end point of the route.
    console.log(startPoint.coordinates[0],startPoint.coordinates[1]);
   // var startPoint1 = new atlas.data.Feature(new atlas.data.Point([startPoint.coordinates[0],startPoint.coordinates[1]]), {
    //    title: 'Fabrikam, Inc.',
    //    icon: 'pin-blue'
 //   });
   // var endPoint1 = new atlas.data.Feature(new atlas.data.Point([endPoint.coordinates[0],endPoint.coordinates[1]]), {
    //    title: 'Microsoft - Lincoln Square',
     //   icon: 'pin-round-blue'
    //});
    //Add the data to the data source.
    datasource.add([startPoint, endPoint]);
    //Fit the map window to the bounding box defined by the start and end positions.
    map.setCamera({
        bounds: atlas.data.BoundingBox.fromData([startPoint, endPoint]),
        pitch: 45,
        padding: 100
    });
    // Use SubscriptionKeyCredential with a subscription key
    
    // Use subscriptionKeyCredential to create a pipeline

    // Construct the RouteURL object
    subscriptionKeyCredential = new atlas.service.SubscriptionKeyCredential(atlas.getSubscriptionKey());
    console.log(subscriptionKeyCredential);
    pipeline = atlas.service.MapsURL.newPipeline(subscriptionKeyCredential);
    console.log(pipeline);
    routeURL = new atlas.service.RouteURL(pipeline);
    console.log(routeURL);
    //Start and end point input to the routeURL
    var coordinates = [[startPoint.geometry.coordinates[0], startPoint.geometry.coordinates[1]], [endPoint.geometry.coordinates[0], endPoint.geometry.coordinates[1]]];
    //Make a search route request for a truck vehicle type
    console.log(routeURL);
    // routeURL.calculateRouteDirections(atlas.service.Aborter.timeout(10000), coordinates, {
    //     travelMode: 'truck',
    //     vehicleWidth: 3,
    //     vehicleHeight: 3,
    //     vehicleLength: 6,
    //     vehicleLoadType: 'USHazmatClass2'
    // }).then((directions) => {
    //     //Get data features from response
    //     var data = directions.geojson.getFeatures();
    //     //Get the route line and add some style properties to it.  
    //     var routeLine = data.features[0];
    //     routeLine.properties.strokeColor = '#2272B9';
    //     routeLine.properties.strokeWidth = 5;
    //     //Add the route line to the data source. We want this to render below the car route which will likely be added to the data source faster, so insert it at index 0.
    //     datasource.add(routeLine, 0);
    // });
    // routeURL.calculateRouteDirections(atlas.service.Aborter.timeout(10000), coordinates).then((directions) => {
    //     //Get data features from response
    //     var data = directions.geojson.getFeatures();
    //     //Get the route line and add some style properties to it.  
    //     var routeLine = data.features[0];
    //     routeLine.properties.strokeColor = '#B76DAB';
    //     routeLine.properties.strokeWidth = 5;
    //     //Add the route line to the data source. We want this to render below the car route which will likely be added to the data source faster, so insert it at index 0.  
    //     datasource.add(routeLine);
    // });
    calculateDirections();


})
}



// ===========================================================Navigation==================================


var animationTime ;


var animation;
function Navigation()
{
    animationTime =distance*1000*2;
    console.log(animationTime);
    document.getElementById("mybtn").disabled = true;

//Create an array of points to define a path to animate along.
// var path  = 
//    routeCoordinates;

// console.log(path);
map.events.add('ready', function () {

  //Load a custom image icon into the map resources.
    map.imageSprite.add('arrow-icon', '/js/map/compass.png').then(function () {

//Create a data source and add it to the map.
// datasource = new atlas.source.DataSource();
// map.sources.add(datasource);

// Create a layer to render the path.
map.layers.add(new atlas.layer.LineLayer(datasource, null, {
strokeColor: 'DodgerBlue',
strokeWidth: 3
}));

//Create a line for the path and add it to the data source.
datasource.add(new atlas.data.LineString(routeCoordinates));

//Create a layer to render a symbol which we will animate.
map.layers.add(new atlas.layer.SymbolLayer(datasource, null, {
iconOptions: {
    //Pass in the id of the custom icon that was loaded into the map resources.
    image: 'arrow-icon',

    //Anchor the icon to the center of the image.
    anchor: 'center',

    //Rotate the icon based on the rotation property on the point data.
    rotation: ['get', 'rotation'],

    //Have the rotation align with the map.
    rotationAlignment: 'map',

    //For smoother animation, ignore the placement of the icon. This skips the label collision calculations and allows the icon to overlap map labels. 
    ignorePlacement: true,

    //For smoother animation, allow symbol to overlap all other symbols on the map.
    allowOverlap: true    
},
textOptions: {
    //For smoother animation, ignore the placement of the text. This skips the label collision calculations and allows the text to overlap map labels.
    ignorePlacement: true,

    //For smoother animation, allow text to overlap all other symbols on the map.
    allowOverlap: true  
},

//Only render the point data in the symbol layer.
filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']] //Only render Point or MultiPoints in this layer.    
}));

//Create a pin and wrap with the shape class and add to data source.
pin = new atlas.Shape(new atlas.data.Feature(new atlas.data.Point(routeCoordinates[0]), {
rotation: 180
}));
datasource.add(pin);

animation = new animations.PathAnimation(routeCoordinates, function (position, heading, progress) {
//Update the rotation of the symbol. 
pin.setProperties({
    rotation: heading
});

//Update the symbols coordinates.
pin.setCoordinates(position);

if (document.getElementById('followSymbol').checked) {
    map.setCamera({
        center: position,
        bearing: heading,
        pitch: 45,
        zoom: 15
    });
}
}, animationTime);
});
});
}






function play() {
    if (animation) {
        animation.play();
    }
}

function pause() {
    if (animation) {
        animation.pause();
    }
}

function stop() {
    if (animation) {
        animation.stop();
    }
}

var animations = (function () {
    var self = this;
    var _delay = 30; //30 = 33.3 frames per second, 16 = 62.5 frames per second

    this.PathAnimation = function (routeCoordinates, intervalCallback, duration) {
        /// <summary>This class extends from the BaseAnimation class and cycles through a set of positions over a period of time, calculating mid-point positions along the way.</summary>
        /// <param name="path" type="Position[]">An array of positions to cycle through.</param>
        /// <param name="intervalCallback" type="Function">A function that is called when a frame is to be rendered. This callback function recieves three values; current position, heading, progress.</param>
        /// <param name="duration" type="Number">Length of time in ms that the animation should run for. Default is 1000 ms.</param>

        var _totalDistance = 0,
            _intervalLocs = [routeCoordinates[0]],
            _intervalHeadings = [],
            _intervalIdx = [0],
            _frameCount = Math.ceil(duration / _delay), idx;

        var progress, dlat, dlon;

        //Calcualte the total distance along the path in degrees.
        for (var i = 0; i < routeCoordinates.length - 1; i++) {
            dlat = (routeCoordinates[i + 1][1] - routeCoordinates[i][1]);
            dlon = (routeCoordinates[i + 1][0] - routeCoordinates[i][0]);

            _totalDistance += Math.sqrt(dlat * dlat + dlon * dlon);
        }

        //Pre-calculate step points for smoother rendering.
        for (var f = 0; f < _frameCount; f++) {
            progress = (f * _delay) / duration;

            var travel = progress * _totalDistance;
            var alpha;
            var dist = 0;
            var dx = travel;

            for (var i = 0; i < routeCoordinates.length - 1; i++) {
                dlat = (routeCoordinates[i + 1][1] - routeCoordinates[i][1]);
                dlon = (routeCoordinates[i + 1][0] - routeCoordinates[i][0]);
                alpha = Math.atan2(dlat * Math.PI / 180, dlon * Math.PI / 180);
                dist += Math.sqrt(dlat * dlat + dlon * dlon);

                if (dist >= travel) {
                    idx = i;
                    break;
                }

                dx = travel - dist;
            }

            if (dx != 0 && idx < routeCoordinates.length - 1) {
                dlat = dx * Math.sin(alpha);
                dlon = dx * Math.cos(alpha);

                var dest = [routeCoordinates[idx][0] + dlon, routeCoordinates[idx][1] + dlat];

                _intervalLocs.push(dest);
                _intervalHeadings.push(atlas.math.getHeading(routeCoordinates[idx], dest));
                _intervalIdx.push(idx);
            }
        }

        //Ensure the last location is the last position in the path.
        _intervalHeadings.push(atlas.math.getHeading(_intervalLocs[_intervalLocs.length - 1], routeCoordinates[routeCoordinates.length - 1]));
        _intervalLocs.push(routeCoordinates[routeCoordinates.length - 1]);
        _intervalIdx.push(routeCoordinates.length - 1);

        if (_intervalHeadings.length < _intervalLocs.length) {
            _intervalHeadings.push(_intervalHeadings[_intervalHeadings.length - 1]);
        }

        return new self.BaseAnimation(
            function (progress, frameIdx) {

                if (intervalCallback) {
                    intervalCallback(_intervalLocs[frameIdx], _intervalHeadings[frameIdx], progress);
                }
            }, duration);
    }

    this.BaseAnimation = function (renderFrameCallback, duration) {
        /// <summary>A base class that can be used to create animations that support play, pause and stop.</summary>
        /// <param name="renderFrameCallback" type="Function">A function that is called when a frame is to be rendered. This function recieves two values; progress and frameIdx.</param>
        /// <param name="duration" type="Number">Length of time in ms that the animation should run for. Default is 1000 ms.</param>

        var _timerId,
            frameIdx = 0,
            _isPaused = true;

        //Varify value
        duration = (duration && duration > 0) ? duration : 1000;

        this.play = function () {
            if (renderFrameCallback) {
                _isPaused = false;

                if (!_timerId) {
                    _timerId = setInterval(function () {
                        if (!_isPaused) {
                            var progress = (frameIdx * _delay) / duration;

                            renderFrameCallback(progress, frameIdx);

                            if (progress >= 1) {
                                reset();
                            }

                            frameIdx++;
                        }
                    }, _delay);
                }
            }
        };

        this.isPlaying = function () {
            return !_isPaused;
        };

        this.pause = function () {
            _isPaused = true;
        };

        this.stop = function () {
            reset();
        };

        function reset() {
            if (_timerId != null) {
                clearInterval(_timerId);
                _timerId = null;
            }

            frameIdx = 0;

            renderFrameCallback(0, frameIdx);
            _isPaused = true;
        }
    }

    return self;
})();




function cluster()
{
 
         //Create a data source and add it to the map.
         datasource1 = new atlas.source.DataSource(null, {
            //Tell the data source to cluster point data.
            cluster: true,

            //The radius in pixels to cluster points together.
            clusterRadius: 1
        });
        var  datasource2 = new atlas.source.DataSource();
        map.sources.add(datasource1);
        map.sources.add(datasource2);

        //Create a heatmap and add it to the map.
        map.layers.add(new atlas.layer.HeatMapLayer(datasource1, null, {
            //Set the weight to the point_count property of the data points.
            weight: ['get', 'point_count'],

            //Optionally adjust the radius of each heat point.
            radius: 10
        }), 'labels');

        map.layers.add(new atlas.layer.HeatMapLayer(datasource2, null, {
            radius: 10,
            opacity: 0.8
        }), 'labels');
        //Load a data set of points, in this case earthquake data from the USGS.
        datasource1.importDataFromUrl('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_month.geojson');
        datasource2.importDataFromUrl('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson');

}








