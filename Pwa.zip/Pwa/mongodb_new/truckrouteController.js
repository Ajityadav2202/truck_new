

Tr=require('./truckrouteModel');

exports.display = function (req, res) {
 Tr.get(function (err, requestroute) {
        if (err) {
            res.json({
                
                status: "error",
                message: err,
            });
        }
        res.json({
            status: "success",
            message: "data retrived successfully",
            data: requestroute
        });
    });
};







exports.add = function (req, res) {
    var requestroute = new Tr();
    requestroute.product_Id = req.body.name ? req.body.product_name : requestroute.product_Id;
    requestroute.product_name = req.body.product_name;
    requestroute.product_weight = req.body.product_weight;
    requestroute.from = req.body.from;
    requestroute.to = req.body.to;
    requestroute.product_type = req.body.product_type;
    requestroute.address = req.body.address;
    requestroute.countryId = req.body.countryId;
    requestroute.stateId=req.body.stateId;
    requestroute.cityId=req.body.cityId;
    requestroute.zipcode=req.body.zipcode;
    requestroute.phonenumber=req.body.phonenumber;
    requestroute.email=req.body.email;
    requestroute.status=req.body.status;
    requestroute.requestedby=req.body.requestedby;
    requestroute.assignuser=req.body.assignuser;
 
// save the contact and check for errors
requestroute.save(function (err) {
     if (err)
           res.json(err);
res.json({
            message: 'request Raised!',
            data: requestroute
        });
    });
};



// exports.display = function (req, res) {
//     Tr.findById(req.params.requestroute_id, function (err, requestroute) {
//         if (err)
//             res.send(err);
//         res.json({
//             message: 'details loading..',
//             data: requestroute
//         });
//     });
// };

exports.updaterequest = function (req, res) {
    Tr.findById(req.params.request_id, function (err, requestroute) {
            if (err)
                res.send(err);
                requestroute.product_Id = req.body.name ? req.body.product_Id : requestroute.product_Id;
                requestroute.product_name = req.body.product_name;
                requestroute.product_weight = req.body.product_weight;
                requestroute.from = req.body.from;
                requestroute.to = req.body.to;
                requestroute.product_type = req.body.product_type;
                requestroute.address = req.body.address;
                requestroute.countryId = req.body.countryId;
                requestroute.stateId=req.body.stateId;
                requestroute.cityId=req.body.cityId;
                requestroute.zipcode=req.body.zipcode;
                requestroute.phonenumber=req.body.phonenumber;
                requestroute.email=req.body.email;
                requestroute.status=req.body.status;
                requestroute.requestedby=req.body.requestedby;
    requestroute.assignuser=req.body.assignuser;

             
    // save the contact and check for errors
    requestroute.save(function (err) {
                if (err)
                    res.json(err);
                res.json({
                    message: 'request Info updated',
                    data: requestroute
                });
            });
        });
    };

    exports.viewrequest = function (req, res) {
        Tr.findById(req.params.request_id, function (err, requestroute) {
            if (err)
                res.send(err);
            res.json({
                message: 'route details loading..',
                data: requestroute
            });
        });
    };








