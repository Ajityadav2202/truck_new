var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var UsersSchema = new Schema({
    userid:{
        type:String,
    },
    username: {
        type: String,
        // required: true
    },
    address:{
        type: String,
        // required: true
    },
    countryId: String,
    stateId: String,
    cityId: String,
    zipcode: String,
    phonenumber: String,
    email: String,
    password:String,
    create_date: {
        type: Date,
        default: Date.now
    }
});


// Export Customer model
var Truckusers = module.exports = mongoose.model('Customers', UsersSchema);




module.exports.get = function (callback, limit) {
    Truckusers.find(callback).limit(limit);
}