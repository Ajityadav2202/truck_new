

userdata=require('./signupModel');

exports.userdisplay = function (req, res) {
 userdata.get(function (err, Truckusers) {
        if (err) {
            res.json({
                status: "error",
                message: err,
            });
        }
        res.json({
            status: "success",
            message: "Users retrived successfully",
            data: Truckusers
        });
    });
};







exports.useradd = function (req, res) {
    var user = new userdata();
    user.userid = req.body.name ? req.body.userid : user.userid;
    user.username = req.body.username;
    user.password = req.body.password;
    user.address = req.body.address;
    user.countryId = req.body.countryId;
    user.stateId=req.body.stateId;
    user.cityId=req.body.cityId;
    user.zipcode=req.body.zipcode;
    user.phonenumber=req.body.phonenumber;
    user.email=req.body.email;
 
// save the contact and check for errors
user.save(function (err) {
     if (err)
           res.json(err);
res.json({
            message: 'request Raised!',
            data: user
        });
    });
};



