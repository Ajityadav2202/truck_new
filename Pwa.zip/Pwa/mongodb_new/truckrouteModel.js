var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var customerRequestSchema = Schema({
    product_Id: {
        type: String,
        // required: true
    },
    product_name: {
        type: String,
        // required: true
    },
    product_weight:{
        type: String,
        // required: true
    },
    from:{
        type: String,
        // required: true
    },
    to:{
        type: String,
        // required: true
    },
    product_type:{
        type: String,
        // required: true
    },
    address:{
        type: String,
        // required: true
    },
    countryId: String,
    stateId: String,
    cityId: String,
    zipcode: String,
    phonenumber: String,
    email: String,
    status:String,
    requestedby:String,
    assignuser:String,
    create_date: {
        type: Date,
        default: Date.now
    }
});


// Export Customer model
var Requestroute = module.exports = mongoose.model('requestroute', customerRequestSchema);




module.exports.get = function (callback, limit) {
    Requestroute.find(callback).limit(limit);
}