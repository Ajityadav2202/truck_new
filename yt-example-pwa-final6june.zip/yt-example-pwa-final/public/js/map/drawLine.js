/**
 * A tool for drawing lines on the map using a mouse.
 * @param map An Azure Maps map instance to attach the drawing tool too. 
 * @param beforeLayer The layer or name of a layer to render the drawing layer before.
 * @param snapFirstPoint A boolean indicating if the line should snap to the first and finish the drawing if the user clicks on the first point.
 * @param drawingEndedCallback A callback function that is fired when a drawing has been completed. If recieves a Shape that contains a LineString feature in it.
 */
var LineDrawingTool = function (map, beforeLayer, snapFirstPoint, drawingEndedCallback) {
    var _self = this;

    var _datasource = new atlas.source.DataSource();
    map.sources.add(_datasource);

    var _activeShape;

    map.layers.add(new atlas.layer.LineLayer(_datasource, null, {
        strokeColor: 'orange',
        strokeWidth: 2
    }), beforeLayer);

    var _handleRadius = 5;

    var _dragHandleLayer = new atlas.layer.BubbleLayer(_datasource, null, {
        color: 'orange',
        radius: _handleRadius,
        strokeColor: 'white',
        strokeWidth: 2
    })
    map.layers.add(_dragHandleLayer, beforeLayer);

    /*********************** 
    * Private Methods 
    ***********************/

    //When the user presses 'esc', take the polygon out of edit mode and re-add to base map.
    document.addEventListener("keydown", function (e) {
        if (e.keyCode === 27 && _activeShape) {
            var coords = _activeShape.getCoordinates();
            coords.pop();

            _activeShape.setCoordinates(coords);
            _self.endDrawing();
        }
    }, false);

    function mouseUp(e) {
        if (_activeShape) {
            var coords = _activeShape.getCoordinates();
            coords.pop(); //Remove the preview coordinate.
            coords.push(e.position); //Add the current coordinate.
            coords.push(e.position); //Add a preview coordinate.
            _activeShape.setCoordinates(coords);
        }
    }

    function dragHandleSelected(e) {
        if (_activeShape) {
            var coords = _activeShape.getCoordinates();
            if (coords.length > 0) {

                //Check to see if user clicked on or close to the first position. 
                var dist = pixelDistance(coords[0], e.position);
                if (dist <= _handleRadius * 1.2) {
                    coords.pop(); //Remove the preview coordinate.
                    coords.pop(); //Remove the last coordinate that was added due to the maps mouseup event.

                    if (snapFirstPoint && coords.length > 1) {
                        coords.push(coords[0]);
                    }

                    _activeShape.setCoordinates(coords);
                    _self.endDrawing();
                }
            }
        }
    }

    function mouseMove(e) {
        if (_activeShape) {
            //Update the last coordinate in the line which is there for preview purposes.
            var coords = _activeShape.getCoordinates();

            if (coords.length > 1) {
                if (snapFirstPoint && pixelDistance(coords[0], e.position) <= _handleRadius * 1.2) {
                    coords[coords.length - 1] = coords[0];
                } else {
                    coords[coords.length - 1] = e.position;
                }

                _activeShape.setCoordinates(coords);
            }
        }
    }

    function mapDoubleClicked(e) {
        if (_activeShape) {
            var coords = _activeShape.getCoordinates();
            coords.pop();

            _activeShape.setCoordinates(coords);
            _self.endDrawing();
        }
    }

    function pixelDistance(pos1, pos2) {
        //Approximately 
        var dLat = (pos2[1] - pos1[1]) * (Math.PI / 180);
        var dLon = (pos2[0] - pos1[0]) * (Math.PI / 180);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos((pos1[1]) * (Math.PI / 180)) * Math.cos((pos2[1]) * (Math.PI / 180)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var groundResolution = Math.cos(pos2[1] * Math.PI / 180) * Math.PI / (Math.pow(2, map.getCamera().zoom) * 256);
        return c / groundResolution;
    }

    /*********************** 
    * Public Methods 
    ***********************/

    /**
     * Clears all data in the drawing layer. 
     */
    this.clear = function () {
        _activeShape = null;
        _datasource.clear();
        _self.endDrawing();
    };

    /**
     * Starts a new drawing session. Clears all data in the drawing layer. 
     */
    this.startDrawing = function () {
        _self.clear();

        map.getCanvasContainer().style.cursor = 'pointer';

        _activeShape = new atlas.Shape({
            "type": "LineString",
            "coordinates": [[]]
        });
        _datasource.add(_activeShape);

        //Show drag handle layer.
        _dragHandleLayer.setOptions({
            visible: true
        });

        //Add mouse events to map.
        map.events.add('mousemove', mouseMove);
        map.events.add('mouseup', mouseUp);
        map.events.add('dblclick', mapDoubleClicked);
        map.events.add('mouseup', _dragHandleLayer, dragHandleSelected);
    };

    /**
     * Stops any current drawing in progress.
     */
    this.endDrawing = function () {
        map.getCanvasContainer().style.cursor = '';

        //Hide drag handle layer.
        _dragHandleLayer.setOptions({
            visible: false
        });

        //Unbind mouse events
        map.events.remove('mousemove', mouseMove);
        map.events.remove('mouseup', mouseUp);
        map.events.remove('dblclick', mapDoubleClicked);
        map.events.remove('mouseup', _dragHandleLayer, dragHandleSelected);

        if (drawingEndedCallback) {
            drawingEndedCallback(_activeShape);
        }
    };
};


// ==============================================


var map, datasource, popup, maxScale = 30, colorExpressions = [], timer, isPaused = true;
        
function GetMap2() {
    //Initialize a map instance.
    map = new atlas.Map('myMap1', {
        center: [-110, 50],
        zoom: 2,
        //Add your Azure Maps subscription key to the map SDK. Get an Azure Maps key at https://azure.com/maps
        authOptions: {
            authType: 'subscriptionKey',
            subscriptionKey: 'HgqenYrB7LRNgoAK4dy8noJ0gsw759iDDZ6PkX5zB-M'
        }
    });
    //Create a legend scale bar.
    createLegendScaleBar();
    //Wait until the map resources are ready.
    map.events.add('ready', function () {
        //Create a popup but leave it closed so we can update it and display it later.
        popup = new atlas.Popup({
            position: [0, 0]
        });
        //Create a data source and add it to the map.
        datasource = new atlas.source.DataSource();
        map.sources.add(datasource);
        //Create an array of expressions to define the fill color based on 
        for (var i = 0; i <= 10; i++) {
            colorExpressions.push([
                'interpolate',
                ['linear'],
                ['get', 'PopChange' + i],
                -maxScale, 'rgb(255,0,255)',       // Magenta
                -maxScale / 2, 'rgb(0,0,255)',     // Blue
                0, 'rgb(0,255,0)',                 // Green
                maxScale / 2, 'rgb(255,255,0)',    // Yellow
                maxScale, 'rgb(255,0,0)'           // Red
            ]);
        }
        //Create a layer to render the polygon data.
        var polygonLayer = new atlas.layer.PolygonLayer(datasource, null, {
            fillColor: colorExpressions[0]
        });
        map.layers.add(polygonLayer, 'labels');
        //Add a mouse move event to the polygon layer to show a popup with information.
        map.events.add('mousemove', polygonLayer, function (e) {
            if (e.shapes && e.shapes.length > 0) {
                var properties = e.shapes[0].getProperties();
                var html = ['<div style="padding:10px"><b>', properties.CountyName, '</b><br />', properties.StateName, '<br />% Pop Change:<br/><table><tr><td>Year</td><td>% Change</td></tr>'];
                for (var i = 0; i <= 10; i++) {
                    var year = 2000 + i;
                    html.push('<tr><td>', year, '</td><td>', properties['PopChange' + i], '%</td></tr>');
                }
                html.push('</table></div>');
                //Update the content of the popup.
                popup.setOptions({
                    content: html.join(''),
                    position: e.position
                });
                //Open the popup.
                popup.open(map);
            }
        });
        //Add a mouse leave event to the polygon layer to hide the popup.
        map.events.add('mouseleave', polygonLayer, function (e) {
            popup.close();
        });
        //Download population estimates for US counties.
        fetch('/js/map/US_County_2010_Population.csv')
            .then(response => response.text())
            .then(function (text) {
                //Parse the CSV file data into a JSON object.
                //For faster cross referencing, create an object that indexes the state and county ids.
                var populationInfo = [];
                //Split the lines of the file.
                var lines = text.split('\n');
                var row, stateId, countyId, censusPop, obj, j;
                //Skip the header row and then parse each row into an object.
                for (var i = 1; i < lines.length; i++) {
                    row = lines[i].split(',');
                    stateId = row[0];
                    countyId = row[1];
                    if (!populationInfo[stateId]) {
                        populationInfo[stateId] = {};
                    }
                    //Get the 2000 population value.
                    censusPop = parseFloat(row[4]);
                    //Create an object to parse the CSV row into.
                    obj = {
                        CountyName: row[3],
                        StateName: row[2],
                        CensusPop2000: censusPop
                    };
                    //Calculate the population % difference from 2000 census, and round to 1 decimal place.
                    for (j = 5; j < row.length; j++) {
                        obj['PopChange' + (j - 5)] = Math.round((parseFloat(row[j]) / censusPop - 1) * 100 * 10) / 10;
                    }
                    populationInfo[stateId][countyId] = obj;
                }
                //Download the county boundary GeoJSON data.
                fetch('/js/map/US_County_Boundaries.json')
                    .then(function (response) {
                        return response.json();
                    }).then(function (response) {
                        var features = response.features;
                        //Loop through each feature and cross reference the population data information.
                        for (var i = 0; i < features.length; i++) {
                            var prop = features[i].properties;
                            if (populationInfo[prop['STATE']] && populationInfo[prop['STATE']][prop['COUNTY']]) {
                                features[i].properties = Object.assign(prop, populationInfo[prop['STATE']][prop['COUNTY']]);
                            }
                        }
                        //Add the feature data to the data source.
                        datasource.add(features);
                        //Create an animation loop. 
                        timer = new FrameAnimationTimer(function (progress, frameIdx) {
                            //Update the fill color expression for the current frame.
                            polygonLayer.setOptions({ fillColor: colorExpressions[frameIdx] });
                            //Update the year in the legend.
                            document.getElementsByClassName('legend-label')[0].innerText = (2000 + frameIdx) + '';
                        }, colorExpressions.length, 10000, true);
                        document.getElementById('playPauseBtn').disabled = '';
                    });
            });
    });
}
function createLegendScaleBar() {
    var canvas = document.getElementById('legendCanvas');
    var ctx = canvas.getContext('2d');
    //Create a linear gradient for the legend.
    var grd = ctx.createLinearGradient(0, 0, 256, 0);
    grd.addColorStop(0, 'rgb(255,0,255)');      // Magenta
    grd.addColorStop(0.25, 'rgb(0,0,255)');     // Blue
    grd.addColorStop(0.5, 'rgb(0,255,0)');      // Green
    grd.addColorStop(0.75, 'rgb(255,255,0)');   // Yellow
    grd.addColorStop(1, 'rgb(255,0,0)');        // Red
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}
function togglePlayPause() {
    if (isPaused) {
        timer.play();
    } else {
        timer.pause();
    }
    isPaused = !isPaused;
}
function FrameAnimationTimer(renderFrameCallback, numFrames, duration, loop) {
    var _timerId,
        frameIdx = 0,
        _isPaused = false;
    duration = (duration && duration > 0) ? duration : 1000;
    delay = duration / (numFrames - 1);
    this.play = function () {
        if (renderFrameCallback) {
            if (_timerId) {
                _isPaused = false;
            } else {
                _timerId = setInterval(function () {
                    if (!_isPaused) {
                        var progress = (frameIdx * delay) / duration;
                        renderFrameCallback(progress, frameIdx);
                        if (progress >= 1) {
                            if (loop) {
                                frameIdx = 0;
                            } else {
                                reset();
                            }
                        }
                        frameIdx++;
                    }
                }, delay);
            }
        }
    };
    this.pause = function () {
        _isPaused = true;
    };
    this.stop = function () {
        reset();
    };
    function reset() {
        if (_timerId != null) {
            clearInterval(_timerId);
        }
        frameIdx = 0;
        _isPaused = false;
    }
};






/**
 * A tool for drawing polygons on the map using a mouse.
 * @param map An Azure Maps map instance to attach the drawing tool too. 
 * @param beforeLayer The layer or name of a layer to render the drawing layer before.
 * @param drawingEndedCallback A callback function that is fired when a drawing has been completed. If recieves a Shape that contains a Polygon feature in it.
 */
var PolygonDrawingTool = function (map, beforeLayer, drawingEndedCallback) {
    var _self = this;

    var _datasource = new atlas.source.DataSource();
    map.sources.add(_datasource);

    var _activeShape;

    var pl = new atlas.layer.PolygonLayer(_datasource, null, {
        fillColor: 'rgba(255,165,0,0.2)'
    });
    map.layers.add(pl, beforeLayer);

    map.layers.add(new atlas.layer.LineLayer(_datasource, null, {
        strokeColor: 'orange',
        strokeWidth: 2
    }), beforeLayer);

    var _handleRadius = 5;

    var _dragHandleLayer = new atlas.layer.BubbleLayer(_datasource, null, {
        color: 'orange',
        radius: _handleRadius,
        strokeColor: 'white',
        strokeWidth: 2
    })
    map.layers.add(_dragHandleLayer, beforeLayer);

    /*********************** 
    * Private Methods 
    ***********************/

    //When the user presses 'esc', take the polygon out of edit mode and re-add to base map.
    document.addEventListener("keydown", function (e) {
        if (e.keyCode === 27 && _activeShape) {
            var ring = _activeShape.getCoordinates()[0];
            ring.pop();

            //Close the ring.
            if (ring.length >= 1) {
                ring.push([ring[0][0], ring[0][1]]); //Add the first coordinate to the end to close the polygon.                    
            }

            _activeShape.setCoordinates([ring]);
            _self.endDrawing();
        }
    }, false);

    function mouseUp(e) {
        if (_activeShape) {
            var ring = _activeShape.getCoordinates()[0];
            ring.pop(); //Remove the preview coordinate.
            ring.push(e.position); //Add the current coordinate.
            ring.push(e.position); //Add a preview coordinate.
            _activeShape.setCoordinates([ring]);
        }
    }

    function dragHandleSelected(e) {
        if (_activeShape) {
            var ring = _activeShape.getCoordinates()[0];
            if (ring.length > 0) {

                //Check to see if user clicked on or close to the first position. 
                var dist = pixelDistance(ring[0], e.position);
                if (dist <= _handleRadius * 1.2) {
                    ring.pop(); //Remove the preview coordinate.
                    ring.pop(); //Remove the last coordinate that was added due to the maps mouseup event.

                    //Close the ring.
                    if (ring.length >= 1) {
                        ring.push([ring[0][0], ring[0][1]]); //Add the first coordinate to the end to close the polygon.                    
                    }

                    _activeShape.setCoordinates([ring]);
                    _self.endDrawing();
                }
            }
        }
    }

    function mouseMove(e) {
        if (_activeShape) {
            //Update the last coordinate in the polygon which is there for preview purposes.
            var ring = _activeShape.getCoordinates()[0];

            if (ring.length > 1) {
                ring[ring.length - 1] = e.position;
                _activeShape.setCoordinates([ring]);
            }
        }
    }

    function pixelDistance(pos1, pos2) {
        //Approximately 
        var dLat = (pos2[1] - pos1[1]) * (Math.PI / 180);  
        var dLon = (pos2[0] - pos1[0]) * (Math.PI / 180);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos((pos1[1]) * (Math.PI / 180)) * Math.cos((pos2[1]) * (Math.PI / 180)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var groundResolution = Math.cos(pos2[1] * Math.PI / 180) * Math.PI / (Math.pow(2, map.getCamera().zoom) * 256);
        return c / groundResolution;
    }

    /*********************** 
    * Public Methods 
    ***********************/

    /**
     * Clears all data in the drawing layer. 
     */
    this.clear = function () {
        _activeShape = null;
        _datasource.clear();
        _self.endDrawing();
    };

    /**
     * Starts a new drawing session. Clears all data in the drawing layer. 
     */
    this.startDrawing = function () {
        _self.clear();

        map.getCanvasContainer().style.cursor = 'pointer';

        _activeShape = new atlas.Shape(new atlas.data.Polygon([[[]]]));
        _datasource.add(_activeShape);

        //Show drag handle layer.
        _dragHandleLayer.setOptions({
            visible: true
        });

        //Add mouse events to map.
        map.events.add('mousemove', mouseMove);
        map.events.add('mouseup', mouseUp);
        map.events.add('mouseup', _dragHandleLayer, dragHandleSelected);
    };

    /**
     * Stops any current drawing in progress.
     */
    this.endDrawing = function () {
        map.getCanvasContainer().style.cursor = '';

        //Hide drag handle layer.
        _dragHandleLayer.setOptions({
            visible: false
        });

        //Unbind mouse events
        map.events.remove('mousemove', mouseMove);
        map.events.remove('mouseup', mouseUp);
        map.events.remove('mouseup', _dragHandleLayer, dragHandleSelected);        

        if (drawingEndedCallback) {
            drawingEndedCallback(_activeShape);
        }
    };
};