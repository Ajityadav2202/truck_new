// $(document).ready(function()
// {
// var rootref=firebase.database().ref().child("user");
// rootref.on("child_added",snap => {
//     alert(snap.val());

// });


// });


$("#submitBtn").click(
    function(){
  
  window.alert("hello");
      var productna = $("#pname").val();
      var from = $("#from").val();
  alert(productna);
  alert(from);
        
    }

  );