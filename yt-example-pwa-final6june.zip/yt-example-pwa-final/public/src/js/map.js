

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
      .then(function() {
        console.log('SW registered');
      });
  }
  

function check(form)/*function to check userid & password*/
{

{
        
    var welcome;
    
        var date = new Date();
    
        var hour = date.getHours();
    
        var minute = date.getMinutes();
    
        var second = date.getSeconds();
    
        if (minute < 10) {
    
            minute = "0" + minute;
    
        }
    
        if (second < 10) {
    
            second = "0" + second;
    
        }
    
        if (hour < 12) {
    
            welcome = "Good morning";
    
        }
    
        else if (hour < 17) {
    
            welcome = "Good afternoon";
    
        }
    
        else {
    
            welcome = "Good evening";
    
        }
}


if(form.uname.value == "praveen" && form.psw.value == "12345")
{
   alert("In function");
  window.localStorage.setItem('Username', 'Praveen');
  alert("Login successfull");

  window.open("/login.html","_self");
  return true;
}
else
{
 alert("Error Password or Username")/*displays error message*/
}




//  /*the following code checkes whether the entered userid and password are matching*/
//  if(form.uname.value == "praveen" && form.psw.value == "123456")
//   {
//      // alert("In function");
//     window.localStorage.setItem('Username', 'Praveen');
//     alert("Login successfull");
//     var username=localStorage.getItem('Username')
//     document.getElementById('username').innerHTML="Hello "+","+welcome;
//     document.getElementById('login-corner').innerHTML=username;
//     document.querySelector('#navbtn').style.display='none';
//     document.querySelector('#span-top').style.display='none';
//     document.querySelector('#id01').style.display='none'
//     document.querySelector('#log-features').style.display='block';
//     document.querySelector('#googleMap').style.display='none';
    
// }
//  else
//  {
//    alert("Error Password or Username")/*displays error message*/
//   }

}
function display()
{
    document.querySelector('#log-features').style.display='none';
    document.querySelector('#googleMap').style.display='block';
}